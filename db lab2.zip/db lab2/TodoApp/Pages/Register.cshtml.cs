using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Identity;
using MySqlConnector;
using System.ComponentModel.DataAnnotations;

public class RegisterModel : PageModel
{
    private readonly IConfiguration _configuration;

    public RegisterModel(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    [BindProperty]
    [Required]
    [StringLength(100)]
    public string Name { get; set; } = "";

    [BindProperty]
    [Required]
    [EmailAddress]
    [StringLength(255)]
    public string Email { get; set; } = "";

    [BindProperty]
    [Required]
    [MinLength(8)]
    public string Password { get; set; } = "";

    public string Message { get; set; } = "";

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
            return Page();

        var connectionString =
            _configuration.GetConnectionString("DefaultConnection");

        if (string.IsNullOrWhiteSpace(connectionString))
        {
            Console.WriteLine(
                "ERROR: DefaultConnection is missing.");

            Message = "Database configuration error.";
            return Page();
        }

        var hasher = new PasswordHasher<RegisterModel>();
        string passwordHash =
            hasher.HashPassword(this, Password);

        try
        {
            await using var connection =
                new MySqlConnection(connectionString);

            await connection.OpenAsync();

            Console.WriteLine(
                $"Connected database: {connection.Database}");

            const string sql = @"
                INSERT INTO users
                    (email, name, password_hash)
                VALUES
                    (@Email, @Name, @PasswordHash);";

            await using var command =
                new MySqlCommand(sql, connection);

            command.Parameters.AddWithValue("@Email", Email);
            command.Parameters.AddWithValue("@Name", Name);
            command.Parameters.AddWithValue(
                "@PasswordHash", passwordHash);

            int rowsAffected =
                await command.ExecuteNonQueryAsync();

            Console.WriteLine(
                $"Rows inserted: {rowsAffected}");

            if (rowsAffected != 1)
            {
                Message = "Registration failed. No row was inserted.";
                return Page();
            }

            // Verify that the registered email exists
            const string verifySql = @"
                SELECT COUNT(*)
                FROM users
                WHERE email = @Email;";

            await using var verifyCommand =
                new MySqlCommand(verifySql, connection);

            verifyCommand.Parameters.AddWithValue("@Email", Email);

            long count = Convert.ToInt64(
                await verifyCommand.ExecuteScalarAsync());

            Console.WriteLine(
                $"Registered email found in database: {count > 0}");

            Message = count > 0
                ? "Registration successful!"
                : "Insert completed, but verification failed.";

            if (count > 0)
            {
                ModelState.Clear();
                Name = "";
                Email = "";
                Password = "";
            }

            return Page();
        }
        catch (MySqlException ex) when (ex.Number == 1062)
        {
            Console.WriteLine(
                $"Duplicate email: {ex.Message}");

            ModelState.AddModelError(
                "Email",
                "This email is already registered.");

            return Page();
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"Registration error: {ex}");

            Message = "Registration failed. Check the application console.";
            return Page();
        }
    }
}
