import os
from pathlib import Path

import mysql.connector
from dotenv import load_dotenv

# Load the .env file located beside this db.py file.
load_dotenv(Path(__file__).resolve().parent / ".env")


def get_db_connection():
    required = ("DB_HOST", "DB_USER", "DB_PASSWORD", "DB_NAME")
    missing = [key for key in required if not os.getenv(key)]
    if missing:
        raise RuntimeError("Missing database settings in .env: " + ", ".join(missing))

    return mysql.connector.connect(
        host=os.getenv("DB_HOST"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME"),
    )
