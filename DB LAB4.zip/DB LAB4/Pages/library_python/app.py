import os
import uuid
from pathlib import Path
from flask import Flask, flash, redirect, render_template, request, url_for
from werkzeug.utils import secure_filename
from db import get_db_connection

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_FOLDER = BASE_DIR / "static" / "images"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

# Database helpers
def query_db(sql, params=()):
    connection = get_db_connection()
    try:
        cursor = connection.cursor(dictionary=True)
        try:
            cursor.execute(sql, params)
            return cursor.fetchall()
        finally:
            cursor.close()
    finally:
        connection.close()

def execute_db(sql, params=()):
    connection = get_db_connection()
    try:
        cursor = connection.cursor()
        try:
            cursor.execute(sql, params)
            connection.commit()
            return cursor.lastrowid
        except Exception:
            connection.rollback()
            raise
        finally:
            cursor.close()
    finally:
        connection.close()

# Image helper
def save_image(upload, folder):
    if not upload or not upload.filename:
        return None

    filename = secure_filename(upload.filename)
    extension = filename.rsplit(".", 1)[-1].lower()
    
    if "." not in filename or extension not in ALLOWED_EXTENSIONS:
        raise ValueError("Image format is not allowed.")
    
    new_name = f"{uuid.uuid4().hex}.{extension}"
    destination = UPLOAD_FOLDER / folder
    destination.mkdir(parents=True, exist_ok=True)
    upload.save(destination / new_name)

    return f"images/{folder}/{new_name}"

def get_image(table, id_column, record_id):
    rows = query_db(
        f"SELECT image_path FROM {table} WHERE {id_column} = %s",
        (record_id,)
    )
    if not rows:
        raise ValueError("Record not found.")
    return rows[0]["image_path"]

def show_message(message, error=None):
    flash(message if error is None else f"{message}: {error}",
          "success" if error is None else "error")

# Home page
@app.route("/")
def index():
    authors = query_db(
        "SELECT * FROM author ORDER BY author_id"
    )

    books = query_db("""
        SELECT b.*, 
               a.name AS author_name,
               p.name AS publisher_name,
               c.name AS category_name
        FROM book b
        LEFT JOIN author a ON b.author_id = a.author_id
        LEFT JOIN publisher p ON b.publisher_id = p.publisher_id
        LEFT JOIN category c ON b.category_id = c.category_id
        ORDER BY b.book_id
    """)

    publishers = query_db(
        "SELECT * FROM publisher ORDER BY publisher_id"
    )

    categories = query_db(
        "SELECT * FROM category ORDER BY category_id"
    )

    members = query_db(
        "SELECT * FROM member ORDER BY member_id"
    )

    loans = query_db("""
        SELECT l.*, b.title AS book_title,
               m.name AS member_name
        FROM loan l
        JOIN book b ON l.book_id = b.book_id
        JOIN member m ON l.member_id = m.member_id
        ORDER BY l.loan_id
    """)

    return render_template(
        "index.html",
        authors=authors,
        books=books,
        publishers=publishers,
        categories=categories,
        members=members,
        loans=loans
    )
# Authors
@app.route("/add_author", methods=["POST"])
def add_author():
    try:
        name = request.form["Name"].strip()
        country = request.form["Country"].strip()
        if not name or not country:
            raise ValueError("Name and country are required.")
        image = save_image(request.files.get("AuthorImage"), "authors")
        execute_db(
            "INSERT INTO author (name, country, image_path) VALUES (%s, %s, %s)",
            (name, country, image)
        )
        show_message("Author added successfully!")
    except Exception as error:
        show_message("Error adding author", error)

    return redirect(url_for("index"))

@app.route("/edit_author", methods=["POST"])
def edit_author():
    try:
        author_id = request.form["Id"]
        name = request.form["Name"].strip()
        country = request.form["Country"].strip()
        image = (
            save_image(request.files.get("AuthorImage"), "authors")
            or get_image("author", "author_id", author_id)
        )

        execute_db(
            """UPDATE author
               SET name=%s, country=%s, image_path=%s
               WHERE author_id=%s""",
            (name, country, image, author_id)
        )
        show_message("Author updated successfully!")
    except Exception as error:
        show_message("Error updating author", error)

    return redirect(url_for("index"))

@app.route("/delete_author", methods=["POST"])
def delete_author():
    try:
        execute_db(
            "DELETE FROM author WHERE author_id=%s",
            (request.form["Id"],)
        )
        show_message("Author deleted successfully!")
    except Exception as error:
        show_message("Could not delete author", error)

    return redirect(url_for("index"))

# Books
@app.route("/add_book", methods=["POST"])
def add_book():
    try:
        title = request.form["Title"].strip()
        price = request.form["Price"]
        author_id = request.form["AuthorId"]
        image = save_image(request.files.get("BookImage"), "books")
        columns = ["title", "price", "author_id", "image_path"]
        values = [title, price, author_id, image]
        # Optional Lab 4 fields
        for field in ("publish_year", "publisher_id", "category_id"):
            value = request.form.get(field)
            if value:
                columns.append(field)
                values.append(value)
        placeholders = ", ".join(["%s"] * len(values))
        sql = f"INSERT INTO book ({', '.join(columns)}) VALUES ({placeholders})"
        execute_db(sql, tuple(values))
        show_message("Book added successfully!")
    except Exception as error:
        show_message("Error adding book", error)

    return redirect(url_for("index"))

@app.route("/edit_book", methods=["POST"])
def edit_book():
    try:
        book_id = request.form["Id"]
        image = (
            save_image(request.files.get("BookImage"), "books")
            or get_image("book", "book_id", book_id)
        )

        fields = {
            "title": request.form["Title"].strip(),
            "price": request.form["Price"],
            "author_id": request.form["AuthorId"],
            "image_path": image
        }
        # Update optional fields only when supplied by the form
        for field in ("publish_year", "publisher_id", "category_id"):
            value = request.form.get(field)
            if value:
                fields[field] = value

        assignments = ", ".join(f"{column}=%s" for column in fields)
        sql = f"UPDATE book SET {assignments} WHERE book_id=%s"

        execute_db(sql, (*fields.values(), book_id))
        show_message("Book updated successfully!")
    except Exception as error:
        show_message("Error updating book", error)

    return redirect(url_for("index"))

@app.route("/delete_book", methods=["POST"])
def delete_book():
    try:
        execute_db(
            "DELETE FROM book WHERE book_id=%s",
            (request.form["Id"],)
        )
        show_message("Book deleted successfully!")
    except Exception as error:
        show_message("Error deleting book", error)

    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)