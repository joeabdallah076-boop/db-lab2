using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MySqlConnector;

namespace TodoApp.Pages.Library;
public class IndexModel : PageModel
{   private readonly IConfiguration _config;
    private readonly IWebHostEnvironment _environment;
    public IndexModel(IConfiguration config, IWebHostEnvironment environment){
         _config = config;
        _environment = environment;
    }
    public List<string[]> Authors { get; set; } = new();
    public List<string[]> Books { get; set; } = new();
    [BindProperty] public int Id { get; set; }
    [BindProperty] public string Name { get; set; } = "";
    [BindProperty] public string Country { get; set; } = "";
    [BindProperty] public string Title { get; set; } = "";
    [BindProperty] public decimal Price { get; set; }
    [BindProperty] public int AuthorId { get; set; }
    [BindProperty] public IFormFile? AuthorImage { get; set; }
    [BindProperty] public IFormFile? BookImage { get; set; }

    private MySqlConnection GetConnection(){
        return new MySqlConnection(
            _config.GetConnectionString("LibraryConnection"));
    }
    private async Task<string?> SaveImageAsync(IFormFile? image, string folder){
        if (image == null || image.Length == 0)
            return null;
        string fileName = Guid.NewGuid().ToString() +
                          Path.GetExtension(image.FileName);
        string directory = Path.Combine(
            _environment.WebRootPath, "images", folder);
        Directory.CreateDirectory(directory);

        string path = Path.Combine(directory, fileName);

        using var stream = new FileStream(path, FileMode.Create);
        await image.CopyToAsync(stream);

        return $"/images/{folder}/{fileName}";
    }

    public async Task OnGetAsync()
    {
        using var con = GetConnection();
        await con.OpenAsync();

        using var cmd = new MySqlCommand(
            "SELECT author_id, name, country, image_path FROM author", con);

        using var r = await cmd.ExecuteReaderAsync();

        while (await r.ReadAsync())
        {
            Authors.Add(new[]
            {
                r["author_id"].ToString()!,
                r["name"].ToString()!,
                r["country"].ToString()!,
                r["image_path"].ToString() ?? ""
            });
        }

        await r.CloseAsync();

        cmd.CommandText =
            "SELECT book_id, title, price, author_id, image_path FROM Book";

        using var reader = await cmd.ExecuteReaderAsync();

        while (await reader.ReadAsync())
        {
            Books.Add(new[]
            {
                reader["book_id"].ToString()!,
                reader["title"].ToString()!,
                reader["price"].ToString()!,
                reader["author_id"].ToString()!,
                reader["image_path"].ToString() ?? ""
            });
        }
    }

    public async Task<IActionResult> OnPostAddAuthorAsync()
    {
        string? image = await SaveImageAsync(AuthorImage, "authors");

        using var con = GetConnection();
        await con.OpenAsync();

        using var cmd = new MySqlCommand(
            "INSERT INTO author (name, country, image_path) VALUES (@name, @country, @image)", con);

        cmd.Parameters.AddWithValue("@name", Name);
        cmd.Parameters.AddWithValue("@country", Country);
        cmd.Parameters.AddWithValue("@image", (object?)image ?? DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostAddBookAsync()
    {
        string? image = await SaveImageAsync(BookImage, "books");

        using var con = GetConnection();
        await con.OpenAsync();

        using var cmd = new MySqlCommand(
            "INSERT INTO Book (title, price, author_id, image_path) VALUES (@title, @price, @authorId, @image)", con);

        cmd.Parameters.AddWithValue("@title", Title);
        cmd.Parameters.AddWithValue("@price", Price);
        cmd.Parameters.AddWithValue("@authorId", AuthorId);
        cmd.Parameters.AddWithValue("@image", (object?)image ?? DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostEditAuthorAsync()
    {
        using var con = GetConnection();
        await con.OpenAsync();

        string? image = await SaveImageAsync(AuthorImage, "authors");

        string sql = image == null
            ? "UPDATE author SET name=@name, country=@country WHERE author_id=@id"
            : "UPDATE author SET name=@name, country=@country, image_path=@image WHERE author_id=@id";

        using var cmd = new MySqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@name", Name);
        cmd.Parameters.AddWithValue("@country", Country);
        cmd.Parameters.AddWithValue("@id", Id);

        if (image != null)
            cmd.Parameters.AddWithValue("@image", image);

        await cmd.ExecuteNonQueryAsync();
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostEditBookAsync()
    {
        using var con = GetConnection();
        await con.OpenAsync();

        string? image = await SaveImageAsync(BookImage, "books");

        string sql = image == null
            ? "UPDATE Book SET title=@title, price=@price, author_id=@authorId WHERE book_id=@id"
            : "UPDATE Book SET title=@title, price=@price, author_id=@authorId, image_path=@image WHERE book_id=@id";

        using var cmd = new MySqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@title", Title);
        cmd.Parameters.AddWithValue("@price", Price);
        cmd.Parameters.AddWithValue("@authorId", AuthorId);
        cmd.Parameters.AddWithValue("@id", Id);

        if (image != null)
            cmd.Parameters.AddWithValue("@image", image);

        await cmd.ExecuteNonQueryAsync();
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostDeleteAuthorAsync()
    {
        using var con = GetConnection();
        await con.OpenAsync();

        using var cmd = new MySqlCommand(
            "DELETE FROM author WHERE author_id=@id", con);

        cmd.Parameters.AddWithValue("@id", Id);
        await cmd.ExecuteNonQueryAsync();

        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostDeleteBookAsync()
    {
        using var con = GetConnection();
        await con.OpenAsync();

        using var cmd = new MySqlCommand(
            "DELETE FROM Book WHERE book_id=@id", con);

        cmd.Parameters.AddWithValue("@id", Id);
        await cmd.ExecuteNonQueryAsync();

        return RedirectToPage();
    }
}