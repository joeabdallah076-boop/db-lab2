using MySqlConnector;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRazorPages();
var app = builder.Build();

try
{    
    var connectionString = builder.Configuration
      .GetConnectionString("DefaultConnection");

    if (string.IsNullOrWhiteSpace(connectionString))
    {
        throw new InvalidOperationException(
            "DefaultConnection is missing from appsettings.json");
    }

    await using var connection =
        new MySqlConnection(connectionString);

    await connection.OpenAsync();

    Console.WriteLine("MySQL connection successful!");

    const string query =
        "SELECT COUNT(*) FROM users";

    await using var command =
        new MySqlCommand(query, connection);

    var result = await command.ExecuteScalarAsync();
    var userCount = Convert.ToInt64(result);

    Console.WriteLine($"Users in database: {userCount}");
}
catch (Exception ex)
{
    Console.WriteLine($"MySQL error: {ex.Message}");
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}
app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthorization();
app.MapStaticAssets();
app.MapRazorPages().WithStaticAssets();
app.Run();
