Python Library module (Flask)

Copy these files/folders into: TodoApp/Pages/library/

The final folder should contain:
  app.py
  db.py
  .env
  requirements.txt
  templates/index.html
  static/images/authors/
  static/images/books/

Create .env by copying .env.example, then enter the MySQL settings for your
existing library database. Do not share or commit the real .env file.

Open a terminal in TodoApp/Pages/library and run:
  python -m pip install -r requirements.txt
  python app.py

Open http://127.0.0.1:5000

The ASP.NET Core project and its registration pages remain C# and are not
changed by this package. Flask runs separately on port 5000. The existing
Razor page index.cshtml can remain in place; Flask uses templates/index.html.

The Python code expects these existing MySQL tables/columns:
  author(author_id, name, country, image_path)
  Book(book_id, title, price, author_id, image_path)
If your actual table/column names differ, adjust the SQL before testing.
